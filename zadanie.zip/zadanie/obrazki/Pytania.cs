﻿using System;
using System.Collections.Generic;
using System.Text;

namespace obrazki
{
    public class Pytania
    {
        public Pytania(string pytanie, string odpA, string odpB, string odpC, string urlObrazka, string poprawnaOdp)
        {
            this.pytanie = pytanie;
            this.odpA = odpA;
            this.odpB = odpB;
            this.odpC = odpC;
            this.urlObrazka = urlObrazka;
            this.poprawnaOdp = poprawnaOdp;
        }

        public String pytanie {  get; set; }
        public String odpA { get; set; }
        public String odpB { get; set; }
        public String odpC { get; set; }
        public String urlObrazka { get; set; }
        public String poprawnaOdp {  get; set; }
    }
}
