﻿using System.Drawing;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace obrazki
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Pytania> PytanieList = new List<Pytania>();
        int index = 0;
        public MainWindow()
        {
            InitializeComponent();
            zaladuj();
        }

        private void zaladuj()
        {
            string nazwaPliku = "plik_do_wczytania (1).txt";
            StreamReader sr = new StreamReader(nazwaPliku);
            string pytania;
            string odp1;
            string odp2;
            string odp3;
            string poprawnaOdp;
            string urlObrazka;
            
            while ((pytania = sr.ReadLine()) != null)
            {
                
                odp1 = sr.ReadLine();
                odp2 = sr.ReadLine();
                odp3= sr.ReadLine();
                poprawnaOdp = sr.ReadLine();
                urlObrazka = sr.ReadLine();

                PytanieList.Add(new Pytania(pytania, odp1, odp2, odp3, urlObrazka, poprawnaOdp));
                
            }
            Odswiez();
            

        }
        private void Dalej_Click(object sender, RoutedEventArgs e)
        {
           
            if (index >= PytanieList.Count -1){
                index = 0;
            }
            else
            {
                index++;
            }
            Odswiez();
        }
        
        public void Odswiez()
        {
            pytanieTresc.Text = PytanieList[index].pytanie;
            odpA.Content = PytanieList[index].odpA;
            odpB.Content = PytanieList[index].odpB;
            odpC.Content = PytanieList[index].odpC;
            string sciezka = "/zdjecia/" + PytanieList[index].urlObrazka;
            zdjecie.Source = new BitmapImage(new Uri(sciezka, UriKind.Relative));
            odpA.IsChecked = false;
            odpB.IsChecked = false;
            odpC.IsChecked = false;
        }

    }
}